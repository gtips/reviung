# reviung39 Upper-middle-plate
Acrylic thickness is 3mm

![REVIUNG39](https://github.com/gtips/reviung/blob/master/reviung39/image/REVIUNG39mdp-1.jpg)  
![REVIUNG39](https://github.com/gtips/reviung/blob/master/reviung39/image/REVIUNG39mdp-2.jpg)  
![REVIUNG39](https://github.com/gtips/reviung/blob/master/reviung39/image/REVIUNG39mdp-3.jpg)  
![REVIUNG39](https://github.com/gtips/reviung/blob/master/reviung39/image/REVIUNG39mdp-4.jpg)  
![REVIUNG39](https://github.com/gtips/reviung/blob/master/reviung39/image/REVIUNG39mdp-5.jpg)  
